﻿namespace KCPlayer.Plugin.LiuXing.LoadLiuXing.Xunbo
{
    public class Search
    {
        public Search()
        {
            var tempword =
                System.Web.HttpUtility.UrlEncode(PublicStatic.SearchWord, System.Text.Encoding.Default).ToUpper();
            if (string.IsNullOrEmpty(tempword)) return;
            var temppath = @"http://www.2tu.cc/search.asp?searchword=" + tempword;
            if (string.IsNullOrEmpty(temppath)) return;
            Com.ListStart.StartList(temppath, new LiuXingType()
                {
                    Encoding = System.Text.Encoding.Default,
                    Proxy = PublicStatic.MyProxy,
                    Type = LiuXingEnum.XunboListItem
                });
        }
    }
}