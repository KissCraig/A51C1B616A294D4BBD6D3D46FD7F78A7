$(document).ready(function(){
	
	$('pic').lightBox({
		
			placeholder : "lightbox/images/loading.gif", 
			effect : "fadeIn" 
		

	});
	
	
});